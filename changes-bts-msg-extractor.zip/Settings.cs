﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.BizTalk.ExplorerOM;
using System.IO;
using static Ox.BizTalk.TrackedMessageExtractor.ConsoleTools;
using System.ComponentModel;
using System.Data;

namespace Ox.BizTalk.TrackedMessageExtractor
{
	/// <summary>
	/// Setings for the application
	/// </summary>
	public class Settings
	{
		[IODescription("--in")]
		public string InFile { get; set; }

		[IODescription("--out")]
		public string OutputDirectory { get; set; }

		[IODescription("--nameproperty")]
		public string FilenameProperty { get; set; }

		[IODescription("--nameschema")]
		public string FilenameSchema { get; set; }

		[IODescription("--mgmtdb")]
		public string BizTalkMgmtDb { get; set; }

		[IODescription("--mgmthost")]
		public string BizTalkMgmtHost { get; set; }

		[IODescription("--dtadb")]
		public string BizTalkDTADb { get; set; }

		[IODescription("--dtahost")]
		public string BizTalkDTAHost { get; set; }

		public bool QuitWhenDone { get; set; }

		[IODescription("--impersonate")]
		public string ImpersonationKey { get; set; }

		private Impersonator Impersonator { get; set; }

		public Settings()
		{
			this.FilenameProperty = "ReceivedFileName";
			this.FilenameSchema = "http://schemas.microsoft.com/BizTalk/2003/file-properties";
			this.QuitWhenDone = false;
			
			try
			{
				BizTalkWmiSearcher.PopulateWmiSettings(this);
			}
			catch { }
		}

		/// <summary>
		/// Checks for missing settings and prompts for them.
		/// </summary>
		public void PromptForMissing()
		{
			if (String.IsNullOrEmpty(this.InFile))
			{
				do
				{
					var file = PromptFor<String>("Message id file");
					if (!File.Exists(file))
					{
						WriteColourfulLine(CON_COLOUR_WARN, "File does not exist.");
					}
					this.InFile = file;
				} while (String.IsNullOrEmpty(this.InFile));
			}

			if(String.IsNullOrEmpty(this.OutputDirectory))
			{
				do
				{
					var dir = PromptFor<String>("Output directory", Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));
					if (!Directory.Exists(dir))
					{
						WriteColourfulLine(CON_COLOUR_WARN, "Directory does not exist.");
					}
					this.OutputDirectory = dir;
				} while (String.IsNullOrEmpty(this.OutputDirectory));
			}

			if (String.IsNullOrEmpty(this.BizTalkMgmtHost))
				this.BizTalkMgmtHost = PromptFor<String>("SQL Host for BizTalkMgmtDb");

			if (String.IsNullOrEmpty(this.BizTalkMgmtDb))
				this.BizTalkMgmtDb = PromptFor<String>("Database name for BizTalkMgmtDb", "BizTalkMgmtDb");

			if (String.IsNullOrEmpty(this.BizTalkDTAHost))
				this.BizTalkDTAHost = PromptFor<String>("SQL Host for BizTalkDTADb", this.BizTalkMgmtHost);

			if (String.IsNullOrEmpty(this.BizTalkDTADb))
				this.BizTalkDTADb = PromptFor<String>("Database name for BizTalkDTADb", "BizTalkDTADb");
		}

		/// <summary>
		/// Prints options to console screen
		/// </summary>
		public void PrintOptions()
        {
			string about = "Bulk saves BizTalk messages from the BizTalkDTADb health and tracking database (if they exist).\nTracking needs to be enabled in BizTalk to save messages.\n\nMessages will be saved to the current working directory unless overridden.\n\nWMI will be used to locate the server, if available.";
			Console.WriteLine(about + Environment.NewLine);
			Console.WriteLine("Usage:");
			Console.WriteLine("  --impersonate=KEY    Windows Credential Store, Generic Credential key. use UNDO as keyword to release");
			Console.WriteLine("  --in=PATH            Line delimetered file of BizTalk message ids");
			Console.WriteLine($"  --mgmthost=SQLHOST   Hostname of Mgmt SQL server/instance to connect to. Default: [{this.BizTalkMgmtHost}]");
			Console.WriteLine($"  --dtahost=SQLHOST    Hostname of the DTA SQL server/isntance. Default: [{this.BizTalkDTAHost}]");
			Console.WriteLine($"  --mgmtdb=DB          Database name of BizTalkMgmtDb. Default: [{this.BizTalkMgmtDb}]");
			Console.WriteLine($"  --dtadb=DB           Database name of the BizTalkDTADb. Default: [{this.BizTalkDTADb}]");
			Console.WriteLine("  --out=PATH           Alternative output directory");
			Console.WriteLine("  --nameschema=URI     Context namespace to use for deriving original filename");
			Console.WriteLine("  --nameproperty=NAME  Context property name to use for deriving original filename");
			Console.WriteLine("  --printsettings               Prints current config settings to the console");
			Console.WriteLine("  --export               Initiate export process");
			Console.WriteLine("  --quit               Do not prompt for program closure at end");

			Console.WriteLine("\nExamples:");

			Console.WriteLine("  --in=messages.txt --out=c:\\ --nameschema=http://schemas.microsoft.com/BizTalk/2003/file-properties --nameproperty=ReceivedFileName --mgmthost=localhost --mgmtdb=BizTalkMgmtDb --dtahost=localhost --dtadb=BizTalkDTADb");

		}

		/// <summary>
		/// Handles external program arguments and converts them to settings
		/// </summary>
		/// <param name="args">External arguments</param>
		/// <returns>False means exit gracefully</returns>
		public bool ProcessArguments(string[] args)
		{
			bool runprogram = true;

			foreach (var arg in args)
			{
				string key = arg;
				string value = arg;
				// Split out arguments from values
				if (arg.Contains("="))
				{
					var split = arg.Split('=');
					if (split.Length != 2)
					{
						throw new ArgumentException("Argument '{0}' not understood.", arg);
					}
					key = split[0];
					value = split[1];
				}

				switch (key.ToLower())
				{
					case "--help":
					case "-h":
					case "/?":
						this.PrintOptions();
						runprogram = true;
						break;

					case "--in":
						File.ReadAllText(value); //Check if the process has file read privilege
						this.InFile = value;
						break;

					case "--mgmthost":
						this.BizTalkMgmtHost = value;
						break;

					case "--dtahost":
						this.BizTalkDTAHost = value;
						break;

					case "--mgmtdb":
						this.BizTalkMgmtDb = value;
						break;

					case "--dtadb":
						this.BizTalkDTADb = value;
						break;

					case "--out":
						Directory.GetFiles(value, "*.dummy"); //dummy operation to validate if directory exists and accessible
						File.Create(Path.Combine(value, "checkwriteprivilege.txt"),1024, FileOptions.DeleteOnClose); //dummy operation to validate if the directory is writable
						
						this.OutputDirectory = value;
						break;

					case "--nameschema":
						this.FilenameSchema = value;
						break;

					case "--nameproperty":
						this.FilenameProperty = value;
						break;

					case "--quit":
						this.QuitWhenDone = true;
						runprogram = false;
						break;
					case "--impersonate":
                        if (value?.ToLowerInvariant() == "UNDO".ToLowerInvariant())
                        {
                            if (this.Impersonator != null)
                            {
								this.Impersonator.Dispose();
								this.Impersonator = null;
								this.ImpersonationKey = null;
                            }
                        }
                        else
                        {
							Credential cred = CredentialManager.ReadCredential(value);
							this.Impersonator = new Impersonator(cred);
							this.Impersonator.Impersonate();
							this.ImpersonationKey = value;

						}


						break;
					case "--printsettings":

                        Console.WriteLine(this.ToString());

						break;
					case "--export":
						Extractor extractor = new Extractor(this);

						if (value?.ToLowerInvariant() == "SQL".ToLowerInvariant())
                        {
							BTSTrackingDBFetcher fetchSqlData = new BTSTrackingDBFetcher(this);
							fetchSqlData.LoadData();
                            foreach (DataRow row in fetchSqlData.Rows)
                            {
								List<object> fileNameParameters = new List<object>();
								fileNameParameters.Add(row["ServiceInstance/ServiceName"]);
								fileNameParameters.Add(row["ServiceInstance/InstanceID"]);
								fileNameParameters.Add(row["message_order"]);
								fileNameParameters.Add(row["Event/Direction"]);
								fileNameParameters.Add(row["Event/Port"]);

								extractor.ExtractMessage($"{row["MessageInstance/InstanceID"]}", fileNameParameters.Select(p=>$"{p}").ToArray());
							}

						}
                        else
                        {
							this.PromptForMissing();            // Fill in the blanks

							using (StreamReader sr = new StreamReader(new FileStream(this.InFile, FileMode.Open, FileAccess.Read)))
							{

								string line;
								while ((line = sr.ReadLine()) != null)
								{
									if (line.Trim().Length > 0)
									{
										extractor.ExtractMessage(line);
									}
								}
							}
						}
						
						break;
					}
			}
			return runprogram;

		}

        public override string ToString()
        {
			StringBuilder retVal = new StringBuilder();

			var props = this.GetType().GetProperties();
			//prop.CustomAttributes.Where(ca=>ca.AttributeType == typeof(IODescriptionAttribute)).Select(ca=>ca.ConstructorArguments[0]).FirstOrDefault().Value
			retVal.AppendLine();
			retVal.Append("".PadRight(10, '='));
			retVal.Append("[ Settings ]");
			retVal.AppendLine("".PadRight(10, '='));

			Dictionary<string, object> propvalues = new Dictionary<string, object>();
			foreach (var prop in props) //beautify properties
            {
				string name = prop.Name;
				object value = prop.GetValue(this);
				object setterParam = prop.CustomAttributes.Where(ca => ca.AttributeType == typeof(IODescriptionAttribute)).Select(ca => ca.ConstructorArguments[0]).FirstOrDefault().Value;
				string leftHandFormatter = "{0} [setter: {1}]";

				name = string.Format(leftHandFormatter, name, setterParam);
				propvalues.Add(name, value);
			}
			int maxPropNameLength = propvalues.Select(pv => pv.Key.Length).Max()+2;

			propvalues.ToList().ForEach((p) => {
				retVal.AppendLine($"██{p.Key.PadRight(maxPropNameLength, '█')} : {p.Value}");
			});//print properties

			retVal.Append("".PadRight(10, '='));
			retVal.Append("[ End of Settings ]");
			retVal.AppendLine("".PadRight(3, '='));
			retVal.AppendLine();

			return retVal.ToString();
        }
    }
}

