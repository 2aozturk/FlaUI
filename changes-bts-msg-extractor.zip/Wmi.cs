﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text;

namespace Ox.BizTalk.TrackedMessageExtractor
{
	/// <summary>
	/// WMI searcher for BizTalk config
	/// </summary>
	internal static class BizTalkWmiSearcher
	{
		private const string MGMT_ROOT = @"root\MicrosoftBizTalkServer";

		public static void PopulateWmiSettings(Settings settings)
		{
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(MGMT_ROOT, "SELECT * FROM MSBTS_GroupSetting");

                foreach (ManagementObject group in searcher.Get())
                {
                    if (group != null)
                    {
                        group.Get();
                        if (string.IsNullOrEmpty(settings.BizTalkMgmtDb)) settings.BizTalkMgmtDb = group.GetMgmtValueSafe<string>("MgmtDbName");
                        if (string.IsNullOrEmpty(settings.BizTalkMgmtHost)) settings.BizTalkMgmtHost = group.GetMgmtValueSafe<string>("MgmtDbServerName");
                        if (string.IsNullOrEmpty(settings.BizTalkDTADb)) settings.BizTalkDTADb = group.GetMgmtValueSafe<string>("TrackingDBName");
                        if (string.IsNullOrEmpty(settings.BizTalkDTAHost)) settings.BizTalkDTAHost = group.GetMgmtValueSafe<string>("TrackingDBServerName");
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine($"BizTalk WDI settings couldn't be acquired so some default values couldn't be set and they need to be set manually! Reason: [{ex.Message}]");
            }
		}

		private static T GetMgmtValueSafe<T>(this ManagementObject mgmtObj, string key)
		{
			T result = default(T);
			try
			{
				if (mgmtObj != null)
				{
					result = (T)mgmtObj[key];
				}
			}
			catch { }
			return result;
		}
	}
}
