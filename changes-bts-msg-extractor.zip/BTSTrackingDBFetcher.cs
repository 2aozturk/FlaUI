﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ox.BizTalk.TrackedMessageExtractor
{
    public class BTSTrackingDBFetcher : DataTable
    {
        public BTSTrackingDBFetcher(Settings setting)
        {
            this.setting = setting;
        }

        private Settings setting;
        public void LoadData()
        {
            SqlConnectionStringBuilder csb = new SqlConnectionStringBuilder();
            csb.InitialCatalog = setting.BizTalkDTADb;
            csb.DataSource = setting.BizTalkDTAHost;
            csb.IntegratedSecurity = true;
            csb.ApplicationName = AppDomain.CurrentDomain.FriendlyName;
            csb.WorkstationID = Environment.MachineName;

            using (SqlConnection conn = new SqlConnection(csb.ToString()))
            {
                using (StreamReader sqlCommandFile = new StreamReader("MessagesQuery.sql"))
                {
                    string sqlCommand = sqlCommandFile.ReadToEnd();
                    using (SqlDataAdapter sqlAdapter = new SqlDataAdapter(sqlCommand, conn))
                    {
                        sqlAdapter.Fill(this);
                    }
                }
            }
        }


    }
}
