﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Principal;
using System.Text;

namespace Ox.BizTalk.TrackedMessageExtractor
{
    public class Impersonator : IDisposable
    {
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword,
       int dwLogonType, int dwLogonProvider, out SafeTokenHandle phToken);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public extern static bool CloseHandle(IntPtr handle);

        const int LOGON32_PROVIDER_DEFAULT = 0;
        //This parameter causes LogonUser to create a primary token.
        const int LOGON32_LOGON_INTERACTIVE = 2;


        SafeTokenHandle safeTokenHandle;
        WindowsImpersonationContext impersonatedUser;
        public Impersonator(Credential credential)
        {
            this.Credential = credential;
        }

        public Credential Credential { get; private set; }
        public void Impersonate() {
            // Call LogonUser to obtain a handle to an access token.
            bool returnValue = LogonUser(Credential.UserName, Credential.DomainName, Credential.Password,
                LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT,
                out safeTokenHandle);

            if (!returnValue) //check if logon succeeded
            {
                Exception ex = new Win32Exception(Marshal.GetLastWin32Error());
                throw ex;
            }

            WindowsIdentity newId = new WindowsIdentity(safeTokenHandle.DangerousGetHandle());
            impersonatedUser = newId.Impersonate();
            Console.WriteLine($"Curently impersonated user name is [{System.Security.Principal.WindowsIdentity.GetCurrent().Name}]");
        }

        ~Impersonator()
        {

            this.Dispose();
        }
        public void Dispose()
        {
            if (safeTokenHandle!=null)
            {
                try
                {
                    safeTokenHandle.Close();

                }
                catch (Exception ex)
                {

                    throw;
                }
            }

            if (impersonatedUser!= null)
            {
                try
                {
                    impersonatedUser.Undo();
                    impersonatedUser.Dispose();
                }
                catch (Exception ex)
                {

                    throw;
                }
            }

            Console.WriteLine($"Impersonation has been released. Current user is [{System.Security.Principal.WindowsIdentity.GetCurrent().Name}]");

        }

    }
    public sealed class SafeTokenHandle : SafeHandleZeroOrMinusOneIsInvalid
    {
        private SafeTokenHandle()
            : base(true)
        {
        }

        [DllImport("kernel32.dll")]
        [ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
        [SuppressUnmanagedCodeSecurity]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CloseHandle(IntPtr handle);

        protected override bool ReleaseHandle()
        {
            return CloseHandle(handle);
        }
    }
}
