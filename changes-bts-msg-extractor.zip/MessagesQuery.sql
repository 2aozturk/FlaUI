/****** Script for SelectTopNRows command from SSMS  ******/
SELECT  --TOP 4	
	ROW_NUMBER() OVER (Partition BY [ServiceInstance/InstanceID] ORDER BY [Event/Timestamp]) [message_order],   
	
	*
  FROM [BizTalkDTADb].[dbo].[dtav_FindMessageFacts]
  WHERE 1=1
  --AND [Event/Timestamp]>'2021-05-04 20:30'
  AND [ServiceInstance/ServiceName]='PSIOrchestrations.SendToPsi'
  ORDER BY [ServiceInstance/InstanceID], [Event/Timestamp]