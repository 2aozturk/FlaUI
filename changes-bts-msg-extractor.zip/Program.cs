using System;
using System.IO;

using static Ox.BizTalk.TrackedMessageExtractor.ConsoleTools;

namespace Ox.BizTalk.TrackedMessageExtractor
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("BizTalk Bulk Tracked Message Extractor");
			Console.WriteLine("Copyright (C) Alastair Grant. 2013.");
			Console.WriteLine("======================================\n");

			Settings settings = new Settings();
			settings.PrintOptions();


			try
			{
				
				while (settings.ProcessArguments(args))
                {
					Console.Write($"{System.Security.Principal.WindowsIdentity.GetCurrent().Name} {DateTime.Now.ToString("HH:mm:ss")}>>");

					string strOptions = Console.ReadLine();
					args = strOptions?.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

				}
			}
			catch(Exception ex)
			{
				WriteError(ex);
			}

			if (!settings.QuitWhenDone)
			{
				WriteColourful(ConsoleColor.Green, "Program Complete.  Press ENTER to end...");
				Console.ReadLine();
			}
		}




	}
}
